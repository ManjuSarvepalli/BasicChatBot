# Dev_AIChatbot_NLP
A basic tutorial on how to create a smart chatbot using AI and NLP


Link to Article : [https://www.analyticsvidhya.com/blog/2021/10/complete-guide-to-build-your-ai-chatbot-with-nlp-in-python/](https://www.analyticsvidhya.com/blog/2021/10/complete-guide-to-build-your-ai-chatbot-with-nlp-in-python/)
